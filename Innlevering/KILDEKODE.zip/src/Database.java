public class Database extends DBConn {
    public Database(String name) {
        System.out.println(name);
    }

}
